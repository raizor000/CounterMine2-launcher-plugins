from scripts.plugin_manager import BasePlugin
import os

class MyAwesomePlugin(BasePlugin):
    # Метаданные, которые отобразятся в UI лаунчера
    name = "Супер Плагин"
    description = "Этот плагин добавляет секретную кнопку и меняет цвет текста."
    version = "1.0.0"
    author = "ТвойНик"
    
    # Путь к иконке относительно файла main.py
    # PluginManager сам преобразует его в абсолютный при загрузке
    icon = "bananvovan.png" 

    def on_load(self):
        """Вызывается сразу при запуске лаунчера (если плагин включен)"""
        print(f"[{self.name}] Плагин инициализирован!")

    def on_ui_ready(self):
        """Вызывается, когда LauncherUI готов. 
        Здесь можно добавлять кнопки в интерфейс или менять стили."""
        ui = self.app.ui
        print(f"[{self.name}] UI готов, можно хукать кнопки.")
        # Пример: ui.play_btn.setText("ПОГНАЛИ!")
